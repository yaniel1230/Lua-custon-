-- 1. INSERTAR EL ITEM EN item_template (Datos técnicos)
INSERT INTO `item_template` (
    `entry`, `class`, `subclass`, `name`, `displayid`, 
    `Quality`, `Flags`, `BuyCount`, `BuyPrice`, `SellPrice`, 
    `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, 
    `StatsCount`, `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, 
    `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, `stat_type5`, `stat_value5`, 
    `dmg_min1`, `dmg_max1`, `dmg_type1`, `delay`, `armor`, 
    `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, 
    `spellcategory_1`, `spellcategorycooldown_1`, `spellid_2`, `spelltrigger_2`, `spellcharges_2`, 
    `spellppmRate_2`, `spellcooldown_2`, `spellcategory_2`, `spellcategorycooldown_2`, 
    `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, 
    `spellcategory_3`, `spellcategorycooldown_3`, `description`, `Material`, `sheath`, `RangedModRange`
) VALUES (
    445090,                           
    2,                                
    7,                                
    "Agonía de Escarcha Mejorada",    
    13262,                            
    6,                                
    32768,                            
    1,                                
    0,                                
    0,                                
    13,                               
    -1,                               
    -1,                               
    284,                              
    80,                               
    5,                                
    4, 500,                           
    3, 250,                           
    7, 200,                           
    32, 100,                          
    36, 100,                          
    650,                              
    1200,                             
    6,                                
    1700,                             
    0,                                
    46619, 2, 0, 0, 0,                
    0, 0,                             
    7294, 2, 0, 0, 0,                 
    0, 0,
    48707, 1, 0, 0, 0,                
    0, 0,
    "Espada legendaria del Rey Exánime que congela el alma de los enemigos. Conserva el aura ominosa de la versión original pero con poder mejorado.",
    1,                                
    3,                                
    0                                 
);

-- 2. AÑADIR EFECTOS VISUALES (Opcional, si no existen)
INSERT IGNORE INTO `spell_visual` (`SpellID`, `VisualID`) VALUES 
(46619, 15880),  
(7294, 10045);   

-- 3. ACTUALIZAR CACHÉ (Obligatorio)
UPDATE `item_template` SET `VerifiedBuild` = 12340 WHERE `entry` = 445090;

-- 4. LOCALIZACIÓN (Opcional, para nombres en español/otros idiomas)
INSERT INTO `item_template_locale` (`ID`, `locale`, `Name`, `Description`) VALUES
(445090, 'esES', 'Agonía de Escarcha Mejorada', 'Espada legendaria del Rey Exánime con aura de escarcha corrupta.');