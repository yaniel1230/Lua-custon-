-- Creación del item con ID 445090 en item_template
INSERT INTO `item_template` (
    `entry`, `class`, `subclass`, `SoundOverrideSubclass`, `name`, 
    `displayid`, `Quality`, `Flags`, `FlagsExtra`, `BuyCount`, 
    `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, 
    `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `RequiredSkillRank`, `requiredspell`, 
    `requiredhonorrank`, `RequiredCityRank`, `RequiredReputationFaction`, `RequiredReputationRank`, 
    `maxcount`, `stackable`, `ContainerSlots`, `StatsCount`, 
    `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, 
    `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, 
    `stat_type5`, `stat_value5`, `stat_type6`, `stat_value6`, 
    `stat_type7`, `stat_value7`, `stat_type8`, `stat_value8`, 
    `stat_type9`, `stat_value9`, `stat_type10`, `stat_value10`, 
    `ScalingStatDistribution`, `ScalingStatValue`, 
    `dmg_min1`, `dmg_max1`, `dmg_type1`, `dmg_min2`, `dmg_max2`, `dmg_type2`, 
    `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, 
    `delay`, `ammo_type`, `RangedModRange`, 
    `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, 
    `spellcategory_1`, `spellcategorycooldown_1`, 
    `spellid_2`, `spelltrigger_2`, `spellcharges_2`, `spellppmRate_2`, `spellcooldown_2`, 
    `spellcategory_2`, `spellcategorycooldown_2`, 
    `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, 
    `spellcategory_3`, `spellcategorycooldown_3`, 
    `description`, `Material`, `sheath`, `VerifiedBuild`
) VALUES (
    445090, -- entry
    2, -- class (weapon)
    7, -- subclass (sword)
    -1, -- SoundOverrideSubclass
    'Agonía de Escarcha Mejorada', -- name
    13262, -- displayid (Frostmourne model)
    6, -- quality (legendary)
    32768, -- Flags
    0, -- FlagsExtra
    1, -- BuyCount
    0, -- BuyPrice (no se puede comprar)
    0, -- SellPrice (no se puede vender)
    13, -- InventoryType (one-hand weapon)
    -1, -- AllowableClass (todos)
    -1, -- AllowableRace (todos)
    284, -- ItemLevel
    80, -- RequiredLevel
    0, -- RequiredSkill
    0, -- RequiredSkillRank
    0, -- requiredspell
    0, -- requiredhonorrank
    0, -- RequiredCityRank
    0, -- RequiredReputationFaction
    0, -- RequiredReputationRank
    1, -- maxcount
    1, -- stackable
    0, -- ContainerSlots
    5, -- StatsCount
    4, 500, -- stat_type1 (strength), value
    3, 250, -- stat_type2 (agility), value
    7, 200, -- stat_type3 (stamina), value
    32, 100, -- stat_type4 (crit), value
    36, 100, -- stat_type5 (haste), value
    0, 0, -- stat_type6
    0, 0, -- stat_type7
    0, 0, -- stat_type8
    0, 0, -- stat_type9
    0, 0, -- stat_type10
    0, -- ScalingStatDistribution
    0, -- ScalingStatValue
    650, -- dmg_min1
    1200, -- dmg_max1
    6, -- dmg_type1 (frost)
    0, 0, 0, -- dmg_min2, dmg_max2, dmg_type2
    0, -- armor
    0, -- holy_res
    0, -- fire_res
    0, -- nature_res
    50, -- frost_res
    0, -- shadow_res
    0, -- arcane_res
    1700, -- delay (1.7 speed)
    0, -- ammo_type
    0, -- RangedModRange
    46619, 2, 0, 0, 0, -- spellid_1 (aura original), trigger (on equip)
    0, 0, -- spellcategory_1, spellcategorycooldown_1
    7294, 2, 0, 0, 0, -- spellid_2 (Frostbrand Weapon effect)
    0, 0, -- spellcategory_2, spellcategorycooldown_2
    48707, 1, 0, 0, 0, -- spellid_3 (Anti-Magic Shell)
    0, 0, -- spellcategory_3, spellcategorycooldown_3
    'Espada legendaria del Rey Exánime que congela el alma de los enemigos. Conserva el aura ominosa de la versión original pero con poder mejorado.',
    1, -- Material (metal)
    3, -- sheath (large weapon)
    12340 -- VerifiedBuild
);

-- Localización en español (opcional)
INSERT INTO `item_template_locale` (`ID`, `locale`, `Name`, `Description`) VALUES
(445090, 'esES', 'Agonía de Escarcha Mejorada', 'Espada legendaria del Rey Exánime con aura de escarcha corrupta.');

-- Efectos visuales (opcional)
INSERT IGNORE INTO `spell_visual` (`SpellID`, `VisualID`) VALUES 
(46619, 15880), -- Visual de aura de escarcha
(7294, 10045); -- Visual de congelación