-- 1. CREATURE_TEMPLATE
INSERT INTO `creature_template` (`entry`, `name`, `subname`, `minlevel`, `maxlevel`, `faction`, `npcflag`, `speed_walk`, `speed_run`, `scale`, `rank`, `unit_class`, `unit_flags`, `type`, `type_flags`, `InhabitType`, `ScriptName`, `AIName`) VALUES
(445051, 'Mercenario de la Arena', 'Desafío de Gurubashi', 80, 80, 35, 1, 1.0, 1.15, 1.2, 1, 1, 0, 7, 0, 3, 'npc_gurubashi_arena', 'SmartAI'),
(445052, 'Campeón de Gurubashi', '', 80, 80, 14, 0, 1.0, 1.15, 1.0, 1, 1, 0, 7, 0, 3, '', 'SmartAI'),
(445053, 'Guardia de Gurubashi', '', 80, 80, 14, 0, 1.0, 1.15, 1.0, 1, 1, 0, 7, 0, 3, '', '');

-- 2. CREATURE_TEMPLATE_MODEL
INSERT INTO `creature_template_model` (`CreatureID`, `Idx`, `CreatureDisplayID`, `DisplayScale`, `Probability`) VALUES
(445051, 0, 19627, 1.0, 100),
(445052, 0, 1126, 1.0, 100),
(445053, 0, 1141, 1.0, 100);

-- 3. CREATURE_QUESTENDER
INSERT INTO `creature_questender` (`id`, `quest`) VALUES (445051, 50001);

-- 4. QUEST_TEMPLATE
INSERT INTO `quest_template` (`Id`, `Title`, `Details`, `Objectives`, `RewardTitle`, `MinLevel`, `QuestLevel`, `RewardMoney`, `RewardBonusMoney`, `RewardDisplaySpell`, `RewardFlags`, `RequiredRaces`) VALUES
(50001, 'El Desafío de Gurubashi', 'Derrota al Campeón de Gurubashi en la Arena. ¡Sobrevive y demuestra tu valía!', 'Mata al Campeón de Gurubashi', 45, 80, 80, 100000, 0, 0, 2, 0);

-- 5. ACHIEVEMENTS
INSERT INTO `achievement_reward` (`ID`, `TitleA`, `TitleH`) VALUES (9001, 46, 46);
INSERT INTO `achievement_criteria_data` (`criteria_id`, `type`, `value1`) VALUES (9001, 11, 50001);

-- 6. SPAWNS
INSERT INTO `creature` (`id`, `map`, `position_x`, `position_y`, `position_z`, `orientation`, `spawntimesecs`) VALUES
(445051, 0, -13204.5, 272.5, 21.8, 5.5, 300);

-- 7. CREATURE_TEXT
INSERT INTO `creature_text` (`CreatureID`, `GroupID`, `ID`, `Text`, `Type`, `Language`, `Probability`, `Emote`, `Duration`, `Sound`, `BroadcastTextId`, `TextRange`, `comment`) VALUES
(445051, 0, 0, "¿Te atreves a desafiar al Campeón de Gurubashi?", 12, 0, 100, 1, 0, 0, 0, 0, "Mercenario - Saludo"),
(445051, 1, 0, "¡Que comience el espectáculo! El Campeón te espera en la arena.", 12, 0, 100, 22, 0, 0, 0, 0, "Mercenario - Aceptar misión"),
(445052, 0, 0, "¡Sangraréis en la arena, gusanos!", 14, 0, 100, 0, 0, 0, 0, 0, "Campeón - Combate"),
(445052, 1, 0, "¡Guards, eliminen a estos intrusos!", 14, 0, 100, 0, 0, 1478, 0, 0, "Campeón - Invocar adds"),
(445052, 2, 0, "¡Nadie sobrevive al Campeón!", 14, 0, 100, 0, 0, 0, 0, 0, "Campeón - Enrage"),
(445052, 3, 0, "¡Imposible...!", 14, 0, 100, 0, 0, 0, 0, 0, "Campeón - Morir");

-- 8. SMART_SCRIPTS
DELETE FROM `smart_scripts` WHERE `entryorguid` = 445052;
INSERT INTO `smart_scripts` (`entryorguid`, `source_type`, `id`, `link`, `event_type`, `event_phase_mask`, `event_chance`, `event_flags`, `event_param1`, `event_param2`, `event_param3`, `event_param4`, `action_type`, `action_param1`, `action_param2`, `action_param3`, `action_param4`, `action_param5`, `action_param6`, `target_type`, `target_param1`, `target_param2`, `target_param3`, `target_x`, `target_y`, `target_z`, `target_o`, `comment`) VALUES
(445052, 0, 0, 0, 4, 0, 100, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Aggro - Say Line 0"),
(445052, 0, 1, 0, 0, 0, 100, 0, 5000, 8000, 9000, 12000, 11, 40505, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, "Combat - Cast Cleave"),
(445052, 0, 2, 0, 0, 0, 100, 0, 3000, 5000, 10000, 15000, 11, 22911, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, "Combat - Cast Charge"),
(445052, 0, 3, 0, 6, 0, 100, 0, 70, 70, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Health 70% - Say Line 1"),
(445052, 0, 4, 0, 6, 0, 100, 0, 70, 70, 0, 0, 11, 40000, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Health 70% - Summon Guards"),
(445052, 0, 5, 0, 6, 0, 100, 0, 70, 70, 0, 0, 11, 42930, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Health 70% - Cast Time Warp"),
(445052, 0, 6, 0, 6, 0, 100, 0, 30, 30, 0, 0, 1, 2, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Health 30% - Say Line 2"),
(445052, 0, 7, 0, 6, 0, 100, 0, 30, 30, 0, 0, 11, 41305, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Health 30% - Cast Enrage"),
(445052, 0, 8, 0, 6, 0, 100, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, "On Death - Say Line 3");

-- 9. CREATURE_TEMPLATE_SPELLS
INSERT INTO `creature_template_spells` (`entry`, `spell1`, `spell2`, `spell3`, `spell4`) VALUES
(445052, 40505, 22911, 41305, 40000);