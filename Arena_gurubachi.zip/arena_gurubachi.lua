local NPC_ID = 445051
local QUEST_ID = 50001
local BOSS_ID = 445052
local GUARD_ID = 445053
local TITLE_REWARD = 45
local ACHIEVEMENT_ID = 9001

-- Configuración
local ARENA_CENTER = {x = -13177.0, y = 332.0, z = 22.0, o = 0.0}
local BOSS_DURATION = 300 -- 5 minutos en segundos
local SOUND_BOSS_SPAWN = 11803
local SOUND_BOSS_DESPAWN = 9378

-- Variables
local bossSpawned = false
local bossGuid = 0
local timer = 0

-- Funciones locales
local function UpdateBossTimer()
    if not bossSpawned then return end
    
    local boss = GetCreatureByGUID(bossGuid)
    if not boss or not boss:IsAlive() then
        bossSpawned = false
        return
    end
    
    timer = timer + 1
    local remaining = BOSS_DURATION - timer
    
    -- Mostrar contador
    if remaining > 0 then
        if remaining % 30 == 0 or remaining <= 10 then
            SendAreaTriggerMessage("|cFFFF0000[Arena]|r Tiempo restante: "..remaining.." segundos.")
        end
    else
        -- Despawnear el boss
        boss:SendUnitYell("¡El tiempo ha expirado!", 0)
        SendAreaTriggerMessage("|cFFFF0000[Arena]|r ¡El Campeón ha desaparecido!")
        boss:PlayDirectSound(SOUND_BOSS_DESPAWN)
        boss:DespawnOrUnsubscribe()
        bossSpawned = false
    end
end

-- Eventos
local function OnGossipHello(event, player, creature)
    if player:GetLevel() == 80 then
        player:GossipMenuAddItem(0, "¿Qué desafío propones?", 0, 1)
        if player:GetQuestStatus(QUEST_ID) == QUEST_STATUS_COMPLETE then
            player:GossipMenuAddItem(0, "He derrotado al Campeón.", 0, 2)
        end
    else
        player:SendBroadcastMessage("|cFFFF0000[Mercenario]|r Solo los campeones nivel 80 pueden enfrentar este desafío.")
    end
    player:GossipSendMenu(1, creature)
end

local function OnGossipSelect(event, player, creature, sender, intid, code)
    if intid == 1 then
        if not player:HasQuest(QUEST_ID) then
            player:AddQuest(QUEST_ID)
            local boss = player:SpawnCreature(BOSS_ID, ARENA_CENTER.x, ARENA_CENTER.y, ARENA_CENTER.z, ARENA_CENTER.o, 2, BOSS_DURATION*1000)
            bossGuid = boss:GetGUID()
            bossSpawned = true
            timer = 0
            
            -- Efectos
            player:SendPlaySound(SOUND_BOSS_SPAWN)
            SendAreaTriggerMessage("|cFFFF0000[Arena]|r ¡El Campeón ha aparecido! Tienes 5 minutos para derrotarlo.")
            CreateLuaEvent(UpdateBossTimer, 1000, 0)
        else
            player:SendBroadcastMessage("|cFFFF0000[Mercenario]|r Ya tienes esta misión activa.")
        end
    elseif intid == 2 then
        player:CompleteQuest(QUEST_ID)
        player:SetTitle(TITLE_REWARD)
        player:SendBroadcastMessage("|cFF00FF00[Mercenario]|r ¡Ahora eres un verdadero Gladiador de Gurubashi!")
    end
    player:GossipComplete()
end

local function OnCreatureKill(event, killer, killed)
    if killed:GetEntry() == BOSS_ID and killer:GetQuestStatus(QUEST_ID) == QUEST_STATUS_INCOMPLETE then
        killer:MarkQuestObjectiveAsComplete(QUEST_ID, 0)
        killer:AddAchievement(ACHIEVEMENT_ID)
        SendWorldMessage("|cFFFF0000[Arena Gurubashi]|r ¡"..killer:GetName().." ha derrotado al Campeón!")
        bossSpawned = false
    end
end

-- Registros
RegisterCreatureGossipEvent(NPC_ID, 1, OnGossipHello)
RegisterCreatureGossipEvent(NPC_ID, 2, OnGossipSelect)
RegisterCreatureEvent(BOSS_ID, 4, OnCreatureKill)