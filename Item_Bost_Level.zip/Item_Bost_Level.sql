-- Eliminar ítems existentes si es necesario
DELETE FROM `item_template` WHERE `entry` IN (800070, 800080);
DELETE FROM `item_template_addon` WHERE `Id` IN (800070, 800080);

-- Moneda Boost Level 70
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `name`, `displayid`, `Quality`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `stackable`, `maxcount`, `Description`, `Bonding`, `Flags`, `FlagsExtra`) 
VALUES 
(800070, 15, 0, 'Piedra de Ascenso Rápido [Nivel 70]', 45849, 3, 8000000, 0, 0, -1, -1, 70, 1, 1, 1, 'Usa este objeto para alcanzar el nivel 70. Incluye equipo azul, montura terrestre y 100 oro. Costo: 800 oro.', 1, 0, 0);

-- Moneda Boost Level 80
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `name`, `displayid`, `Quality`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `stackable`, `maxcount`, `Description`, `Bonding`, `Flags`, `FlagsExtra`) 
VALUES 
(800080, 15, 0, 'Piedra de Ascenso Rápido [Nivel 80]', 45850, 4, 15000000, 0, 0, -1, -1, 80, 1, 1, 1, 'Usa este objeto para alcanzar el nivel 80. Incluye equipo épico, montura voladora, 500 oro y profesiones básicas. Costo: 1500 oro.', 1, 0, 0);

-- Datos adicionales
INSERT INTO `item_template_addon` (`Id`, `FlagsCu`) VALUES 
(800070, 0),
(800080, 0);