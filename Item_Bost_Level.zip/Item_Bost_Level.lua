local BOOST_COIN_70 = 800070
local BOOST_COIN_80 = 800080

-- Tabla de monturas por raza
local RACE_MOUNTS = {
    [1]  = {2411, 5656},  -- Humano
    [2]  = {5655, 5665},  -- Orco
    [3]  = {8595, 5668},  -- Enano
    [4]  = {13321, 5663}, -- Elfo de la Noche
    [5]  = {13322, 5663}, -- No-muerto
    [6]  = {8563, 5668},  -- Tauren
    [7]  = {8586, 5665},  -- Gnomo
    [8]  = {13321, 5663}, -- Trol
    [10] = {29743, 29744},-- Sangre Elfo
    [11] = {28481, 29745} -- Draenei
}

-- Equipo básico por clase y nivel
local CLASS_GEAR = {
    [70] = {
        [1]  = {27461, 27463, 27465, 28484, 27517}, -- Guerrero (Placas)
        [2]  = {27461, 27463, 27465, 28484, 27517}, -- Paladín (Placas)
        [3]  = {27453, 27455, 27457, 28293, 27939}, -- Cazador (Malla)
        [4]  = {27437, 27439, 27441, 28485},       -- Pícaro (Cuero)
        [5]  = {27468, 27469, 27470, 28486},       -- Sacerdote (Tela)
        [6]  = {27461, 27463, 27465, 28484, 27517},-- Caballero de la Muerte (Placas)
        [7]  = {27453, 27455, 27457, 28486},       -- Chamán (Malla)
        [8]  = {27468, 27469, 27470, 28486},       -- Mago (Tela)
        [9]  = {27468, 27469, 27470, 28486},       -- Brujo (Tela)
        [11] = {27437, 27439, 27441, 28484}        -- Druida (Cuero)
    },
    [80] = {
        [1]  = {42948, 44092, 42950, 42951, 42952, 42984, 42985, 37134, 37135}, -- Guerrero
        [2]  = {42948, 44092, 42950, 42951, 42952, 42984, 42985, 37134, 37135}, -- Paladín
        [3]  = {42943, 44091, 42944, 42945, 42946, 42947, 42992, 37139, 37140}, -- Cazador
        [4]  = {42952, 44093, 42954, 42955, 42956, 42957, 42991, 37131, 37132}, -- Pícaro
        [5]  = {42958, 44095, 42959, 42960, 42961, 42962, 42985, 37137, 37138}, -- Sacerdote
        [6]  = {42948, 44092, 42950, 42951, 42952, 42984, 42985, 37134, 37135}, -- Caballero de la Muerte
        [7]  = {42943, 44091, 42944, 42945, 42946, 42947, 42992, 37139, 37140}, -- Chamán
        [8]  = {42958, 44095, 42959, 42960, 42961, 42962, 42985, 37137, 37138}, -- Mago
        [9]  = {42958, 44095, 42959, 42960, 42961, 42962, 42985, 37137, 37138}, -- Brujo
        [11] = {42952, 44093, 42954, 42955, 42956, 42957, 42991, 37131, 37132}  -- Druida
    }
}

local function GiveClassEquipment(player, class, level)
    local gear = CLASS_GEAR[level][class]
    if gear then
        for _, itemId in ipairs(gear) do
            player:AddItem(itemId, 1)
        end
    end
end

local function GiveStarterKit(player, level)
    -- Montura terrestre
    local race = player:GetRace()
    if RACE_MOUNTS[race] then
        player:AddItem(RACE_MOUNTS[race][1], 1)
    end
    
    -- Montura voladora para nivel 80
    if level == 80 then
        player:AddItem(44160, 1) -- Montura voladora épica
        player:LearnSpell(34091) -- Vuelo experto
    end
    
    -- Equipo según clase
    local class = player:GetClass()
    GiveClassEquipment(player, class, level)
    
    -- Objetos básicos
    player:AddItem(6948, 1)  -- Piedra de hogar
    player:AddItem(2901, 4)  -- Piedras de hogar adicionales
    
    -- Oro
    if level == 70 then
        player:ModifyMoney(1000000) -- 100 oro
    else
        player:ModifyMoney(5000000) -- 500 oro
    end
    
    -- Profesiones básicas
    if level == 80 then
        player:SetSkill(333, 1, 450, 450) -- Encantamiento WotLK
        player:SetSkill(202, 1, 450, 450) -- Ingeniería WotLK
        player:AddItem(36934, 20) -- Tumba de ojo de tigre (gemas)
    end
end

local function BoostPlayer(player, item, target, level, cost)
    -- Verificar nivel
    if player:GetLevel() >= level then
        player:SendAreaTriggerMessage("|cFFFF0000Ya tienes nivel "..level.." o superior.|r")
        return false
    end
    
    -- Verificar oro
    if not player:HasEnoughMoney(cost) then
        player:SendAreaTriggerMessage(string.format("|cFFFF0000Necesitas %d oro para usar este objeto.|r", cost/10000))
        return false
    end
    
    -- Cobrar el oro
    player:ModifyMoney(-cost)
    
    -- Subir de nivel
    player:SetLevel(level)
    
    -- Aprender habilidades
    player:LearnClassSpells(true)
    player:LearnClassTalents()
    player:LearnSpell(258) -- Atajo universal
    
    -- Reputaciones básicas
    if level == 80 then
        player:SetReputation(946, 42000) -- Argent Crusade
        player:SetReputation(947, 42000) -- The Wyrmrest Accord
    end
    
    -- Kit de inicio
    GiveStarterKit(player, level)
    
    -- Mensajes
    player:SendBroadcastMessage(string.format("|cFF00FF00¡Felicidades! Has alcanzado el nivel %d!|r", level))
    player:SendAreaTriggerMessage(string.format("|cFF00FF00¡Ahora eres nivel %d!|r", level))
    
    if level == 80 then
        player:SendBroadcastMessage("|cFF00FF00Has recibido una montura voladora épica y 500 oro!|r")
    end
    
    -- Consumir el ítem
    item:RemoveFromWorld()
    return false
end

local function OnUse70(event, player, item, target)
    return BoostPlayer(player, item, target, 70, 8000000) -- 800 oro
end

local function OnUse80(event, player, item, target)
    return BoostPlayer(player, item, target, 80, 15000000) -- 1500 oro
end

RegisterItemEvent(BOOST_COIN_70, 2, OnUse70)
RegisterItemEvent(BOOST_COIN_80, 2, OnUse80)