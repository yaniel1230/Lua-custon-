-- Guardaespaldas LUA para AzerothCore

local npcGuardaespaldas = 445083
local itemToken = 445081

local GuardaespaldasData = {}

local Tier10Set = {
    head = 65374,
    shoulders = 65375,
    chest = 65376,
    wrists = 65377,
    hands = 65378,
    waist = 65379,
    legs = 65380,
    feet = 65381,
    back = 65382,
    finger1 = 65383,
    finger2 = 65384,
    trinket1 = 65385,
    trinket2 = 65386,
    -- arma no se cambia
}

local function EquiparTier10(guard)
    for slot, itemid in pairs(Tier10Set) do
        guard:EquipItem(itemid)
    end
end

local function CrearGuardaespaldas(event, player, item, target)
    if item:GetEntry() == itemToken then
        local playerGUID = player:GetGUIDLow()
        if GuardaespaldasData[playerGUID] then
            player:SendBroadcastMessage("Ya tienes un guardaespaldas activo.")
            return false
        end
        -- Invocar NPC cerca
        local guard = player:SpawnCreature(npcGuardaespaldas, player:GetX()+1, player:GetY()+1, player:GetZ(), player:GetO(), 3, 600000)
        if guard then
            guard:SetLevel(player:GetLevel())
            EquiparTier10(guard)
            guard:SetOwnerGUID(player:GetGUID())
            GuardaespaldasData[playerGUID] = {npc = guard, tiempo = 600} -- duración en minutos
            player:SendBroadcastMessage("Guardaespaldas contratado por 10 horas.")
            item:RemoveItem(1)
        end
        return false
    end
end

local function GuardarTiempo(event, diff)
    for playerGUID, data in pairs(GuardaespaldasData) do
        data.tiempo = data.tiempo - diff/60000 -- convertir ms a min
        if data.tiempo <= 0 then
            if data.npc and data.npc:IsAlive() then
                data.npc:DespawnOrUnsummon()
            end
            GuardaespaldasData[playerGUID] = nil
        end
    end
end

local function DespedirGuardaespaldas(event, player, command)
    local playerGUID = player:GetGUIDLow()
    local data = GuardaespaldasData[playerGUID]
    if not data then
        player:SendBroadcastMessage("No tienes un guardaespaldas activo.")
        return false
    end
    local tiempoRestante = data.tiempo
    local refund = math.floor(tiempoRestante * 100) -- ejemplo: 100 cobre por minuto restante
    if data.npc and data.npc:IsAlive() then
        data.npc:DespawnOrUnsummon()
    end
    GuardaespaldasData[playerGUID] = nil
    player:ModifyMoney(refund)
    player:SendBroadcastMessage("Guardaespaldas despedido. Se te han reembolsado "..refund.." de cobre.")
    return false
end

RegisterItemEvent(itemToken, 2, CrearGuardaespaldas) -- OnUse

RegisterPlayerEvent(3, function(event, player) -- Player logout
    local playerGUID = player:GetGUIDLow()
    if GuardaespaldasData[playerGUID] and GuardaespaldasData[playerGUID].npc then
        GuardaespaldasData[playerGUID].npc:DespawnOrUnsummon()
        GuardaespaldasData[playerGUID] = nil
    end
end)

CreateLuaEvent(GuardarTiempo, 60000) -- Cada minuto

RegisterPlayerEvent(42, function(event, player, message, type, language) -- chat command /despedirguarda
    if message:lower() == ".despedirguarda" then
        return DespedirGuardaespaldas(event, player, message)
    end
end)
