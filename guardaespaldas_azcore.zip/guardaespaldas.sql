
-- Crear item token que activa el guardaespaldas
INSERT INTO item_template (entry, class, subclass, name1, displayid, Quality, Flags, BuyPrice, SellPrice, InventoryType, AllowableClass, AllowableRace, itemlevel, maxcount)
VALUES
(445081, 15, 0, 'Token para Contratar Guardaespaldas', 35523, 4, 0, 1000000, 250000, 0, -1, -1, 1, 1);

-- Crear NPC Guardaespaldas
INSERT INTO creature_template (entry, name, subname, modelid1, faction, npcflags, speed_walk, speed_run, scale, rank, dmgschool, BaseAttackTime, RangeAttackTime, BaseVariance, RangeVariance, unit_class, unit_flags, dynamicflags, family, trainer_type, trainer_spell, trainer_class, trainer_race)
VALUES
(445083, 'Guardaespaldas', '', 31234, 35, 0, 1.0, 1.5, 1.0, 0, 0, 2000, 2000, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);

-- Crear NPC Vendedor Token (Neutral, accesible para Horda y Alianza)
INSERT INTO creature_template (entry, name, subname, modelid1, faction, npcflags, speed_walk, speed_run, scale, rank, dmgschool, BaseAttackTime, RangeAttackTime, BaseVariance, RangeVariance, unit_class, unit_flags, dynamicflags, family, trainer_type, trainer_spell, trainer_class, trainer_race)
VALUES
(445084, 'Vendedor de Guardaespaldas', '', 34872, 35, 1, 1.0, 1.5, 1.0, 0, 0, 2000, 2000, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);

-- Crear vínculo vendedor vende el token
INSERT INTO npc_vendor (entry, item, maxcount, incrtime, extendedcost)
VALUES
(445084, 445081, 0, 0, 0);
