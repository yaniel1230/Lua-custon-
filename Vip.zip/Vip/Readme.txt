INSTRUCCIONES DE INSTALACIÓN:

1. Importar los archivos SQL:
   - vip_npc.sql → Base de datos 'world'
   - vip_item.sql → Base de datos 'world'

2. Colocar el script Lua:
   - vip_system.lua → /data/scripts/custom/

3. Recargar el servidor:
   - .reload eluna
   - O reiniciar completamente

UBICACIONES NPC:
- Stormwind: -8914.53, -133.93, 80.53
- Orgrimmar: 1562.54, -4418.07, 7.85