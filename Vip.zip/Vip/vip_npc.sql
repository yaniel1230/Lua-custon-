-- Eliminar existentes
DELETE FROM `creature_template` WHERE `entry` = 99999;
DELETE FROM `creature_template_model` WHERE `CreatureID` = 99999;
DELETE FROM `creature` WHERE `id` = 99999;

-- Crear NPC
INSERT INTO `creature_template` (
    `entry`, `name`, `subname`, `minlevel`, `maxlevel`, `faction`, 
    `npcflag`, `speed_walk`, `speed_run`, `scale`, `ScriptName`
) VALUES (
    99999, 'Banquero VIP', 'Sistema de Recompensas', 80, 80, 35, 
    1, 1.0, 1.14286, 1.0, 'npc_vip_banker'
);

-- Modelo visual
INSERT INTO `creature_template_model` (`CreatureID`, `Idx`, `CreatureDisplayID`) 
VALUES (99999, 0, 19646);

-- Spawns
INSERT INTO `creature` (`guid`, `id`, `map`, `position_x`, `position_y`, `position_z`) VALUES 
(500000, 99999, 0, -8914.53, -133.93, 80.53),
(500001, 99999, 1, 1562.54, -4418.07, 7.85);