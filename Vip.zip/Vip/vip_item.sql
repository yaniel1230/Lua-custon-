-- Anillo VIP
DELETE FROM `item_template` WHERE `entry` = 445082;
INSERT INTO `item_template` (
    `entry`, `class`, `subclass`, `name`, `displayid`, `Quality`, 
    `BuyPrice`, `SellPrice`, `InventoryType`, `ScriptName`
) VALUES (
    445082, 4, 0, 'Anillo VIP', 5233, 1,
    1000, 250, 11, 'item_vip_ring'
);