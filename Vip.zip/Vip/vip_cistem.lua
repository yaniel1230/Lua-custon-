local NPC_ENTRY = 99999
local VIP_ITEM_ENTRY = 445082
local RING_COST = 1000

-- Configuración
local EFFECTS = {
    BUY = { sound = 8888, visual = 59 },
    DENY = { sound = 8458, visual = 134 },
    REWARD = { sound = 12038 },
    UPGRADE = { sound = 6444, visual = 113 }
}

local VIP_LEVELS = {
    [1] = { gold = 10000, cooldown = 120, name = "|cFF808080Novato|r", upgrade_cost = 50000, effect = 59 },
    [2] = { gold = 15000, cooldown = 90,  name = "|cFF1EFF00Avanzado|r", upgrade_cost = 100000, effect = 64 },
    [3] = { gold = 25000, cooldown = 60,  name = "|cFF0070DDÉlite|r", upgrade_cost = 200000, effect = 65 },
    [4] = { gold = 50000, cooldown = 30,  name = "|cFFA335EEMaestro|r", upgrade_cost = 500000, effect = 66 },
    [5] = { gold = 100000, cooldown = 15, name = "|cFFFF8000Leyenda|r", effect = 113 }
}

-- Funciones principales
local function GetVipLevel(player)
    local item = player:GetItemByEntry(VIP_ITEM_ENTRY)
    return item and math.min(item:GetQuality(), #VIP_LEVELS) or 0
end

local function BuyVipRing(player, creature)
    if player:HasItem(VIP_ITEM_ENTRY) then
        player:SendBroadcastMessage("|cFFFF0000¡Ya tienes un Anillo VIP!|r")
        player:PlayDirectSound(EFFECTS.DENY.sound)
        creature:CastSpell(player, EFFECTS.DENY.visual, true)
        return false
    end
    
    if not player:HasEnoughMoney(RING_COST) then
        player:SendBroadcastMessage(string.format("|cFFFF0000Necesitas |r|cFFFFD700%d|r|cFFFF0000 de oro.|r", RING_COST))
        player:PlayDirectSound(EFFECTS.DENY.sound)
        return false
    end
    
    player:ModifyMoney(-RING_COST)
    local item = player:AddItem(VIP_ITEM_ENTRY, 1)
    if item then item:SetQuality(1); item:Save() end
    
    player:PlayDirectSound(EFFECTS.BUY.sound)
    creature:CastSpell(player, EFFECTS.BUY.visual, true)
    player:SendBroadcastMessage("|TInterface\\Icons\\inv_jewelry_ring_03:30|t |cFF00FF00¡Anillo VIP obtenido! (Nivel 1)|r")
    return true
end

local function UpgradeRing(player, creature)
    local vipLevel = GetVipLevel(player)
    if vipLevel >= #VIP_LEVELS then
        player:SendBroadcastMessage("|cFFFF8000¡Ya tienes el nivel máximo!|r")
        player:PlayDirectSound(EFFECTS.DENY.sound)
        return false
    end
    
    local cost = VIP_LEVELS[vipLevel].upgrade_cost
    if not player:HasEnoughMoney(cost) then
        player:SendBroadcastMessage(string.format("|cFFFF0000Necesitas |r|cFFFFD700%d|r|cFFFF0000 oro para mejorar.|r", cost))
        player:PlayDirectSound(EFFECTS.DENY.sound)
        return false
    end
    
    player:ModifyMoney(-cost)
    local item = player:GetItemByEntry(VIP_ITEM_ENTRY)
    if item then item:SetQuality(vipLevel + 1); item:Save() end
    
    player:PlayDirectSound(EFFECTS.UPGRADE.sound)
    creature:CastSpell(player, VIP_LEVELS[vipLevel + 1].effect, true)
    player:SendBroadcastMessage(string.format("|cFF00FF00¡Anillo mejorado a |r%s|cFF00FF00!|r", VIP_LEVELS[vipLevel + 1].name))
    return true
end

local function ClaimReward(player, creature)
    local vipLevel = GetVipLevel(player)
    if vipLevel == 0 then return false end
    
    local reward = VIP_LEVELS[vipLevel]
    local lastClaim = player:GetData("vip_last_claim") or 0
    local remaining = reward.cooldown - (os.time() - lastClaim)
    
    if remaining > 0 then
        player:SendBroadcastMessage(string.format("|cFFFF0000Espera |r|cFFFFD700%d|r|cFFFF0000 segundos.|r", remaining))
        player:PlayDirectSound(EFFECTS.DENY.sound)
        return false
    end
    
    player:ModifyMoney(reward.gold)
    player:SetData("vip_last_claim", os.time())
    player:PlayDirectSound(EFFECTS.REWARD.sound)
    creature:CastSpell(player, reward.effect, true)
    
    player:SendBroadcastMessage(string.format(
        "|TInterface\\Icons\\inv_misc_coin_02:30|t |cFF00FF00+%d oro (|r%s|cFF00FF00)|r",
        reward.gold, reward.name
    ))
    return true
end

-- Diálogos
local function OnGossipHello(event, player, creature)
    player:GossipClearMenu()
    local vipLevel = GetVipLevel(player)
    
    if vipLevel == 0 then
        player:GossipMenuAddItem(0, "|TInterface\\Icons\\inv_jewelry_ring_03:25|t |cFFFFD700Comprar Anillo VIP|r", 0, 1)
        player:GossipMenuAddItem(0, "|cFFAAAAAACosto: |r|cFFFFD7001,000|r|cFFAAAAAA oro|r", 0, 99)
    else
        local reward = VIP_LEVELS[vipLevel]
        player:GossipMenuAddItem(0, "|TInterface\\Icons\\inv_jewelry_ring_03:25|t |cFF00FF00Nivel: "..reward.name.."|r", 0, 99)
        
        local lastClaim = player:GetData("vip_last_claim") or 0
        if (os.time() - lastClaim) >= reward.cooldown then
            player:GossipMenuAddItem(3, "|TInterface\\Icons\\inv_misc_coin_02:25|t |cFFFFFF00Reclamar "..reward.gold.." oro|r", 0, 2)
        else
            player:GossipMenuAddItem(0, "|cFFFF0000Cooldown: |r|cFFFFD700"..remaining.."s|r", 0, 99)
        end
        
        if vipLevel < #VIP_LEVELS then
            player:GossipMenuAddItem(3, "|TInterface\\Icons\\spell_chargepositive:25|t |cFF00FFFFMejorar a "..VIP_LEVELS[vipLevel+1].name.."|r", 0, 3)
            player:GossipMenuAddItem(0, "|cFFAAAAAACosto: |r|cFFFFD700"..reward.upgrade_cost.."|r|cFFAAAAAA oro|r", 0, 99)
        end
    end
    
    player:GossipSendMenu(1, creature)
end

local function OnGossipSelect(event, player, creature, sender, intid, code)
    if intid == 1 then BuyVipRing(player, creature)
    elseif intid == 2 then ClaimReward(player, creature)
    elseif intid == 3 then UpgradeRing(player, creature) end
    
    player:GossipComplete()
    OnGossipHello(event, player, creature)
end

-- Registrar eventos
RegisterCreatureGossipEvent(NPC_ENTRY, 1, OnGossipHello)
RegisterCreatureGossipEvent(NPC_ENTRY, 2, OnGossipSelect)

print("[Sistema VIP] Cargado para NPC "..NPC_ENTRY.." - Anillo "..VIP_ITEM_ENTRY)