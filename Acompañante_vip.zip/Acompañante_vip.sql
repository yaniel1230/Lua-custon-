-- TRANSACCIÓN COMPLETA PARA MÁXIMA SEGURIDAD
START TRANSACTION;

-- 1. LIMPIEZA PREVIA CON DEPENDENCIAS
DELETE FROM `item_template_locale` WHERE `ID` = 445090;
DELETE FROM `creature_template_locale` WHERE `entry` = 445080;
DELETE FROM `npc_text` WHERE `ID` = 60000;
DELETE FROM `creature_model_info` WHERE `DisplayID` IN (23920, 27510, 45678);
DELETE FROM `creature_template_model` WHERE `CreatureID` = 445080;
DELETE FROM `creature_template` WHERE `entry` = 445080;
DELETE FROM `item_template` WHERE `entry` = 445090;

-- 2. ÍTEM VIP CON STATS COMPLETOS
INSERT INTO `item_template` (
    `entry`, `class`, `subclass`, `name`, `displayid`, `Quality`, `Flags`, `FlagsExtra`, 
    `BuyCount`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`,
    `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `stackable`, `maxcount`, `bonding`,
    `description`, `Material`, `startquest`, `flagsCustom`, `VerifiedBuild`
) VALUES (
    445090, 12, 0, 'Talismán VIP Élite', 46779, 4, 134217728, 0,
    1, 10000000, 0, 12, -1, -1,
    1, 20, 0, 1, 1, 1,
    'Otorga beneficios VIP por 7 días. Invoca un asistente exclusivo.',
    3, 0, 2, 12340
);

-- 3. PLANTILLA DE CRIATURA CON VALORES EXACTOS
INSERT INTO `creature_template` (
    `entry`, `name`, `subname`, `IconName`, `minlevel`, `maxlevel`, `faction`,
    `npcflag`, `scale`, `rank`, `type`, `type_flags`, `HealthModifier`, `MovementType`,
    `HoverHeight`, `unit_class`, `unit_flags`, `unit_flags2`, `dynamicflags`, `ScriptName`, `VerifiedBuild`
) VALUES (
    445080, 'Asistente VIP', 'Servicios Premium', 'Directions', 80, 80, 35,
    1, 1.15, 1, 7, 138936390, 50.0, 0,
    1.0, 1, 768, 2048, 0, '', 12340
);

-- 4. MODELOS CON VALORES ÚNICOS Y FÍSICA PRECISA
INSERT INTO `creature_template_model` (`CreatureID`, `Idx`, `CreatureDisplayID`, `DisplayScale`, `Probability`, `VerifiedBuild`) VALUES
(445080, 0, 23920, 1.15, 100, 12340), -- Modelo principal
(445080, 1, 27510, 1.20, 0, 12340),   -- Variante élite
(445080, 2, 45678, 1.10, 0, 12340);    -- Variante alternativa

INSERT INTO `creature_model_info` (`DisplayID`, `BoundingRadius`, `CombatReach`, `Gender`, `DisplayID_Other_Gender`, `VerifiedBuild`) VALUES
(23920, 0.347, 1.5, 2, 0, 12340),  -- Valores exactos para modelo estándar
(27510, 0.383, 1.8, 2, 0, 12340),  -- Valores para modelo premium
(45678, 0.306, 1.3, 2, 0, 12340);  -- Valores para modelo alternativo

-- 5. TEXTO Y LOCALIZACIONES OPTIMIZADAS
INSERT INTO `npc_text` (`ID`, `text0_0`, `VerifiedBuild`) VALUES
(60000, '¡Saludos, $n! Soy tu asistente VIP personal. ¿En qué puedo ayudarte hoy?', 12340);

INSERT INTO `item_template_locale` (`ID`, `locale`, `Name`, `Description`) VALUES 
(445090, 'esES', 'Talismán VIP Élite', 'Otorga beneficios VIP por 7 días. Invoca un asistente exclusivo.');

INSERT INTO `creature_template_locale` (`entry`, `locale`, `Name`, `Title`) VALUES 
(445080, 'esES', 'Asistente VIP', 'Servicios Premium');

COMMIT;