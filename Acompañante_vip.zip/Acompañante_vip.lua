local VIP_SYSTEM = {
    ITEM_ID = 445090,
    CREATURE_ID = 445080,
    AURAS = {
        VIP = 46308,        -- Visual "Exhausto"
        MOUNT = 32724,      -- Montura rápida
        REPAIR = 30562      -- Efecto reparación
    },
    DURATIONS = {
        VIP = 604800,       -- 7 días en segundos
        ASSISTANT = 300,    -- 5 minutos
        MOUNT = 60          -- 1 minuto
    },
    SOUNDS = {
        ACTIVATE = 8888,
        RESET = 11803,
        REPAIR = 10561,
        BANK = 13200
    }
}

-- Cache de funciones globales
local GetPlayerName = GetPlayerName
local SendNotification = SendNotification
local math_floor = math.floor

local function FormatTime(seconds)
    local days = math_floor(seconds / 86400)
    local hours = math_floor((seconds % 86400) / 3600)
    
    if days > 0 then
        return days..(days == 1 and " día" or " días")
    else
        return hours..(hours == 1 and " hora" or " horas")
    end
end

local function OnVIPUse(event, player, item)
    if not player:IsInWorld() then return false end
    
    if player:HasAura(VIP_SYSTEM.AURAS.VIP) then
        local remaining = player:GetAuraTimeRemaining(VIP_SYSTEM.AURAS.VIP)
        player:SendNotification("VIP activo ("..FormatTime(remaining).." restantes)")
        return false
    end

    -- Aplicar VIP con manejo de errores
    if not player:AddAura(VIP_SYSTEM.AURAS.VIP, player):SetDuration(VIP_SYSTEM.DURATIONS.VIP) then
        player:SendNotification("Error al activar VIP")
        return false
    end

    -- Spawn del asistente con verificación
    local x, y, z, o = player:GetLocation()
    x = x + math.cos(o) * 2
    y = y + math.sin(o) * 2
    
    local assistant = player:SpawnCreature(VIP_SYSTEM.CREATURE_ID, x, y, z, o, 3, VIP_SYSTEM.DURATIONS.ASSISTANT)
    if not assistant then
        player:SendNotification("Error al invocar asistente")
        return false
    end
    
    assistant:SetFacing(o)
    assistant:MoveFollow(player, 3, math.pi/4)
    
    player:SendBroadcastMessage("|cFF00FF00[VIP]|r Beneficios activados")
    player:PlayDirectSound(VIP_SYSTEM.SOUNDS.ACTIVATE)
    
    -- Log de activación
    print("[VIP] Activado por: "..GetPlayerName(player).." - Duración: "..FormatTime(VIP_SYSTEM.DURATIONS.VIP))
    return true
end

local function OnGossipVIP(event, player, creature)
    if not player:HasAura(VIP_SYSTEM.AURAS.VIP) then
        creature:DespawnOrUnsummon()
        return
    end

    player:GossipSetText(string.format(
        "|cFF00FF96Asistente VIP|r\n\nTiempo: |cFFFFFF00%s|r\n\nServicios disponibles:",
        FormatTime(player:GetAuraTimeRemaining(VIP_SYSTEM.AURAS.VIP))
    )
    
    -- Menú optimizado con cache de textos
    local menuItems = {
        {5, "Resetear instancias", 1, "Spell_Nature_TimeStop"},
        {1, "Reparar equipo gratis", 2, "Trade_BlackSmithing"},
        {2, "Banco personal", 3, "INV_Misc_Bag_10"},
        {6, "Montura rápida (1 min)", 4, "Ability_Mount_WhiteTiger"},
        {0, "Salir", 5, "Achievement_Reputation_08"}
    }
    
    for _, item in ipairs(menuItems) do
        player:GossipMenuAddItem(
            item[1], 
            "|TInterface\\Icons\\"..item[4]..":30|t "..item[2], 
            0, item[3]
        )
    end
    
    player:GossipSendMenu(1, creature)
end

local function OnSelectVIP(event, player, creature, sender, intid)
    if not player:HasAura(VIP_SYSTEM.AURAS.VIP) then
        player:GossipComplete()
        creature:DespawnOrUnsummon()
        return
    end

    -- Tabla de acciones optimizada
    local actions = {
        [1] = function() -- Reset instancias
            player:ResetInstances()
            player:SendNotification("Instancias reseteadas")
            player:PlayDirectSound(VIP_SYSTEM.SOUNDS.RESET)
        end,
        [2] = function() -- Reparar
            player:DurabilityRepairAll(false, 0)
            player:AddAura(VIP_SYSTEM.AURAS.REPAIR, player)
            player:SendNotification("Equipo reparado gratis")
            player:PlayDirectSound(VIP_SYSTEM.SOUNDS.REPAIR)
        end,
        [3] = function() -- Banco
            player:SendShowBank(player:GetGUID())
            player:PlayDirectSound(VIP_SYSTEM.SOUNDS.BANK)
        end,
        [4] = function() -- Montura
            player:RemoveAura(VIP_SYSTEM.AURAS.MOUNT)
            if player:AddAura(VIP_SYSTEM.AURAS.MOUNT, player):SetDuration(VIP_SYSTEM.DURATIONS.MOUNT * 1000) then
                player:SendNotification("Montura VIP activada")
            end
        end
    }

    if actions[intid] then actions[intid]() end
    player:GossipComplete()
end

-- REGISTRO OPTIMIZADO DE EVENTOS
local function RegisterVIPSystem()
    RegisterItemEvent(VIP_SYSTEM.ITEM_ID, 2, OnVIPUse)
    RegisterCreatureGossipEvent(VIP_SYSTEM.CREATURE_ID, 1, OnGossipVIP)
    RegisterCreatureGossipEvent(VIP_SYSTEM.CREATURE_ID, 2, OnSelectVIP)
    
    print("[Sistema VIP 100%] Registrado correctamente. Item:", VIP_SYSTEM.ITEM_ID)
end

RegisterVIPSystem()