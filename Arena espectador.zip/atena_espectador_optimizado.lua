local ARENA_SPECTATOR = {
    NPC_ENTRY = 445060,
    NPC_ENTRY_HORDE = 445061, -- Opcional: NPC diferente para Horda
    ARENA_MAPS = {[559]=true, [562]=true, [572]=true, [617]=true, [618]=true},
    COST = 0,
    MIN_LEVEL = 10,
    COOLDOWN = 10,
    CACHE_TTL = 5,
    TELEPORT_HEIGHT = 15,
    -- Ubicaciones de retorno por facción
    RETURN_LOCATIONS = {
        [0] = {map=0, x=-8866.5, y=673.6, z=97.9, o=0},  -- Alianza: Ventormenta
        [1] = {map=1, x=1569.97, y=-4397.41, z=16.06, o=0} -- Horda: Entrañas
    }
}

-- Cache y estado
local activeSpectators = {}
local lastUsage = {}
local arenaCache = {timestamp=0, data={}}

-- Función para determinar si un jugador es de la Horda
local function IsHorde(player)
    local race = player:GetRace()
    return race == 2 or race == 5 or race == 6 or race == 8 or race == 9 or race == 10
end

local function GetReturnLocation(player)
    return ARENA_SPECTATOR.RETURN_LOCATIONS[IsHorde(player) and 1 or 0]
end

local function IsArena(mapId)
    return ARENA_SPECTATOR.ARENA_MAPS[mapId]
end

local function CanUse(player)
    if player:GetLevel() < ARENA_SPECTATOR.MIN_LEVEL then
        return false, "Requieres nivel "..ARENA_SPECTATOR.MIN_LEVEL.." para usar este servicio."
    end
    
    if ARENA_SPECTATOR.COST > 0 and player:GetCoinage() < (ARENA_SPECTATOR.COST * 10000) then
        return false, "Necesitas "..ARENA_SPECTATOR.COST.." oro para espectar."
    end
    
    local last = lastUsage[player:GetGUIDLow()] or 0
    if os.difftime(os.time(), last) < ARENA_SPECTATOR.COOLDOWN then
        return false, "Debes esperar "..(ARENA_SPECTATOR.COOLDOWN - os.difftime(os.time(), last)).." segundos."
    end
    
    return true
end

local function GetActiveArenas()
    local now = os.time()
    if now - arenaCache.timestamp < ARENA_SPECTATOR.CACHE_TTL then
        return arenaCache.data
    end
    
    local activeArenas = {}
    for mapId in pairs(ARENA_SPECTATOR.ARENA_MAPS) do
        local players = GetPlayersInMap(mapId)
        for _, player in ipairs(players) do
            if not player:IsSpectator() then
                local teamId = player:GetArenaTeamId(0) or player:GetArenaTeamId(1) or player:GetArenaTeamId(2)
                if teamId and teamId > 0 then
                    activeArenas[mapId] = activeArenas[mapId] or {}
                    activeArenas[mapId][teamId] = activeArenas[mapId][teamId] or {
                        name = player:GetArenaTeamName(teamId),
                        members = {},
                        faction = player:GetTeam() -- 0: Alianza, 1: Horda
                    }
                    table.insert(activeArenas[mapId][teamId].members, player)
                end
            end
        end
    end
    
    arenaCache = {timestamp=now, data=activeArenas}
    return activeArenas
end

local function GetRandomArenaPlayer(playerFaction)
    local arenas = GetActiveArenas()
    local candidates = {}
    
    for _, teams in pairs(arenas) do
        for _, team in pairs(teams) do
            -- Opcional: Filtrar por facción si se desea
            -- if not playerFaction or team.faction == playerFaction then
                for _, player in ipairs(team.members) do
                    table.insert(candidates, player)
                end
            -- end
        end
    end
    
    return #candidates > 0 and candidates[math.random(#candidates)] or nil
end

local function EnterSpectatorMode(player, target)
    player:SetSpectator(true)
    player:SetGMVisible(false)
    player:SetFFA(false)
    player:SetSanctuary(true)
    player:SetFly(true)
    
    local x, y, z = target:GetLocation()
    player:Teleport(target:GetMapId(), x, y, z + ARENA_SPECTATOR.TELEPORT_HEIGHT, 0)
    
    if ARENA_SPECTATOR.COST > 0 then
        player:ModifyMoney(-(ARENA_SPECTATOR.COST * 10000))
    end
    
    activeSpectators[player:GetGUIDLow()] = true
    lastUsage[player:GetGUIDLow()] = os.time()
    
    player:SendBroadcastMessage("|cFF00FF00Ahora estás espectando la arena!|r")
    player:SendBroadcastMessage("|cFFFF0000Usa el mismo NPC para dejar de espectar.|r")
end

local function ExitSpectatorMode(player)
    player:SetSpectator(false)
    player:SetGMVisible(true)
    player:SetSanctuary(false)
    player:SetFly(false)
    
    activeSpectators[player:GetGUIDLow()] = nil
    
    local loc = GetReturnLocation(player)
    player:Teleport(loc.map, loc.x, loc.y, loc.z, loc.o)
    player:SendBroadcastMessage("|cFF00FF00Has dejado el modo espectador.|r")
end

-- Menús adaptados por facción
local function OnGossipHello(event, player, creature)
    -- Verificar facción del NPC (opcional)
    -- if (IsHorde(player) and creature:GetEntry() ~= ARENA_SPECTATOR.NPC_ENTRY_HORDE) or
    --    (not IsHorde(player) and creature:GetEntry() ~= ARENA_SPECTATOR.NPC_ENTRY) then
    --    return
    -- end
    
    local canUse, errMsg = CanUse(player)
    if not canUse then
        player:GossipMenuAddItem(0, errMsg, 0, 0)
        player:GossipSendMenu(1, creature)
        return
    end
    
    local factionText = IsHorde(player) and "|cFFFF0000[Horda]|r" or "|cFF0070DD[Alianza]|r"
    player:GossipMenuAddItem(0, "Maestro de Arena "..factionText, 0, 0)
    player:GossipMenuAddItem(0, "---------------------", 0, 0)
    
    if activeSpectators[player:GetGUIDLow()] then
        player:GossipMenuAddItem(0, "|cFFFF0000Dejar de espectar|r", 0, 3)
    else
        player:GossipMenuAddItem(0, "|cFF00FF00Espectar arena aleatoria|r", 0, 1)
        player:GossipMenuAddItem(0, "|cFF00CCFFListar arenas activas|r", 0, 2)
        player:GossipMenuAddItem(0, "|cFFFFFF00Información|r", 0, 4)
    end
    
    player:GossipSendMenu(1, creature)
end

local function OnGossipSelect(event, player, creature, sender, intid, code)
    if intid == 1 then -- Espectar aleatorio
        local target = GetRandomArenaPlayer(player:GetTeam())
        if target then
            EnterSpectatorMode(player, target)
        else
            player:SendBroadcastMessage("|cFFFF0000No hay arenas activas en este momento.|r")
        end
        player:GossipComplete()
    
    elseif intid == 2 then -- Listar arenas
        local arenas = GetActiveArenas()
        if next(arenas) then
            player:SendBroadcastMessage("|cFF00FF00Arenas activas:|r")
            for mapId, teams in pairs(arenas) do
                local mapName = GetMapName(mapId) or "Arena "..mapId
                player:SendBroadcastMessage("|cFFFF0000=== "..mapName.." ===|r")
                for _, team in pairs(teams) do
                    local members = {}
                    for _, member in ipairs(team.members) do
                        table.insert(members, member:GetName())
                    end
                    local factionIcon = team.faction == 1 and "|TInterface\\PVPFrame\\PVP-Currency-Horde:18:18|t" or "|TInterface\\PVPFrame\\PVP-Currency-Alliance:18:18|t"
                    player:SendBroadcastMessage(factionIcon.." "..team.name..": "..table.concat(members, ", "))
                end
            end
        else
            player:SendBroadcastMessage("|cFFFF0000No hay arenas activas.|r")
        end
        player:GossipComplete()
    
    elseif intid == 3 then -- Salir
        ExitSpectatorMode(player)
        player:GossipComplete()
    
    elseif intid == 4 then -- Información
        player:SendBroadcastMessage("|cFF00FF00Modo Espectador de Arena|r")
        player:SendBroadcastMessage("|cFF00CCFFPuedes observar cualquier arena en progreso.|r")
        player:SendBroadcastMessage("|cFFFFFF00Como espectador:|r")
        player:SendBroadcastMessage("- Eres invisible para los participantes")
        player:SendBroadcastMessage("- Puedes volar libremente")
        player:SendBroadcastMessage("- No puedes interactuar con el combate")
        player:GossipComplete()
    end
end

-- Registrar eventos para ambos NPCs
RegisterCreatureGossipEvent(ARENA_SPECTATOR.NPC_ENTRY, 1, OnGossipHello)
RegisterCreatureGossipEvent(ARENA_SPECTATOR.NPC_ENTRY, 2, OnGossipSelect)

-- Si usas NPC diferente para Horda
if ARENA_SPECTATOR.NPC_ENTRY_HORDE then
    RegisterCreatureGossipEvent(ARENA_SPECTATOR.NPC_ENTRY_HORDE, 1, OnGossipHello)
    RegisterCreatureGossipEvent(ARENA_SPECTATOR.NPC_ENTRY_HORDE, 2, OnGossipSelect)
end

print("[Arena Spectator] Sistema cargado para ambos bandos. NPCs: "..ARENA_SPECTATOR.NPC_ENTRY..(ARENA_SPECTATOR.NPC_ENTRY_HORDE and ", "..ARENA_SPECTATOR.NPC_ENTRY_HORDE or ""))