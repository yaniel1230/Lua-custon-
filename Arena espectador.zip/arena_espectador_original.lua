local ARENA_SPECTATOR_NPC = {
    -- ID del NPC que actuará como espectador de arena
    NPCEntry = 445060, -- ID del NPC especificado
    
    -- ID de los mapas de arena permitidos
    ArenaMaps = {
        559, -- Arena de las Sombras
        562, -- Círculo de Sangre
        572, -- Ruinas de Lordaeron
        617, -- La Cámara de la Alianza
        618  -- La Cámara de la Horda
    },
    
    -- Opciones de menú
    MenuOptions = {
        [1] = "Listar arenas activas",
        [2] = "Espectar una arena aleatoria",
        [3] = "Dejar de espectar",
        [4] = "Información sobre el modo espectador"
    },
    
    -- Coste en oro para espectar (0 para gratis)
    Cost = 0,
    
    -- Nivel mínimo requerido
    MinLevel = 0,
    
    -- Mensajes
    Messages = {
        Greeting = "¡Saludos, aventurero! Soy el Maestro de Espectadores de Arena. Puedo transportarte para que observes emocionantes combates de arena.",
        NoArena = "Actualmente no hay arenas en progreso. Vuelve más tarde.",
        AlreadySpectating = "Ya estás en modo espectador.",
        NotEnoughGold = "Necesitas %d oro para espectar.",
        EnteringSpectator = "Teletransportándote como espectador... Disfruta del combate!",
        LeavingSpectator = "Saliendo del modo espectador.",
        InvalidOption = "Opción no válida.",
        NoPermission = "No cumples los requisitos para espectar.",
        SpectatingInfo = "|cFF00FF00Información del modo espectador:|r\n\n- Eres completamente invisible para los participantes\n- No puedes interactuar con los jugadores\n- Tienes capacidad de volar libremente\n- Eres invulnerable a todo daño\n\nPara salir del modo espectador, habla conmigo nuevamente."
    }
}

-- Tabla para almacenar espectadores
local activeSpectators = {}

-- Función para verificar si un jugador está en una arena
local function IsPlayerInArena(player)
    local mapId = player:GetMapId()
    for _, arenaMap in ipairs(ARENA_SPECTATOR_NPC.ArenaMaps) do
        if mapId == arenaMap then
            return true
        end
    end
    return false
end

-- Función para encontrar arenas activas
local function GetActiveArenas()
    local activeArenas = {}
    local players = GetPlayersInWorld()
    
    for _, player in ipairs(players) do
        if IsPlayerInArena(player) and not player:IsSpectator() then
            local mapId = player:GetMapId()
            local teamId = player:GetArenaTeamId(0) or player:GetArenaTeamId(1) or player:GetArenaTeamId(2)
            
            if teamId and teamId > 0 then
                if not activeArenas[mapId] then
                    activeArenas[mapId] = {}
                end
                
                if not activeArenas[mapId][teamId] then
                    activeArenas[mapId][teamId] = {
                        teamName = player:GetArenaTeamName(teamId),
                        members = {}
                    }
                end
                
                table.insert(activeArenas[mapId][teamId].members, player)
            end
        end
    end
    
    return activeArenas
end

-- Función para teletransportar a un jugador como espectador
local function TeleportToSpectate(player, target)
    -- Verificar coste
    if ARENA_SPECTATOR_NPC.Cost > 0 and player:GetCoinage() < (ARENA_SPECTATOR_NPC.Cost * 10000) then
        player:SendBroadcastMessage(string.format(ARENA_SPECTATOR_NPC.Messages.NotEnoughGold, ARENA_SPECTATOR_NPC.Cost))
        return false
    end
    
    -- Aplicar modos de espectador
    player:SetSpectator(true)
    player:SetGMVisible(false)
    player:SetFFA(false)
    player:SetSanctuary(true)
    player:SetFly(true)
    
    -- Teletransportar al jugador
    local map = target:GetMap()
    local x, y, z = target:GetLocation()
    player:Teleport(map:GetMapId(), x, y, z + 15, 0) -- 15 metros arriba para mejor vista
    
    -- Cobrar el coste si es necesario
    if ARENA_SPECTATOR_NPC.Cost > 0 then
        player:ModifyMoney(-(ARENA_SPECTATOR_NPC.Cost * 10000))
    end
    
    -- Registrar como espectador activo
    activeSpectators[player:GetGUIDLow()] = true
    
    player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.EnteringSpectator)
    return true
end

-- Función para sacar a un jugador del modo espectador
local function RemoveSpectatorMode(player)
    if activeSpectators[player:GetGUIDLow()] then
        player:SetSpectator(false)
        player:SetGMVisible(true)
        player:SetSanctuary(false)
        player:SetFly(false)
        
        -- Teletransportar de vuelta al NPC
        local npc = player:GetNearestCreature(ARENA_SPECTATOR_NPC.NPCEntry, 100)
        if npc then
            player:Teleport(npc:GetMapId(), npc:GetX(), npc:GetY(), npc:GetZ(), npc:GetO())
        else
            -- Si no hay NPC cerca, teletransportar a capital
            player:Teleport(0, -8866.5, 673.6, 97.9, 0) -- Ventormenta
        end
        
        activeSpectators[player:GetGUIDLow()] = nil
        player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.LeavingSpectator)
        return true
    end
    return false
end

-- Menú principal del NPC
local function OnGossipHello(event, player, creature)
    -- Verificar requisitos
    if player:GetLevel() < ARENA_SPECTATOR_NPC.MinLevel then
        player:GossipMenuAddItem(0, ARENA_SPECTATOR_NPC.Messages.NoPermission, 0, 0)
        player:GossipSendMenu(1, creature)
        return
    end
    
    -- Mostrar mensaje de bienvenida
    player:GossipMenuAddItem(0, ARENA_SPECTATOR_NPC.Messages.Greeting, 0, 0)
    player:GossipMenuAddItem(0, "---------------------", 0, 0)
    
    -- Mostrar menú diferente si ya es espectador
    if activeSpectators[player:GetGUIDLow()] then
        player:GossipMenuAddItem(0, ARENA_SPECTATOR_NPC.MenuOptions[3], 0, 3)
    else
        for i, option in pairs(ARENA_SPECTATOR_NPC.MenuOptions) do
            if i ~= 3 then -- Excluir "Dejar de espectar" si no está espectando
                player:GossipMenuAddItem(0, option, 0, i)
            end
        end
    end
    
    player:GossipSendMenu(1, creature)
end

-- Manejo de selecciones del menú
local function OnGossipSelect(event, player, creature, sender, intid, code)
    if intid == 1 then -- Listar arenas activas
        local arenas = GetActiveArenas()
        if next(arenas) == nil then
            player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.NoArena)
        else
            player:SendBroadcastMessage("|cFF00FF00Arenas activas:|r")
            for mapId, teams in pairs(arenas) do
                local mapName = GetMapName(mapId) or ("Mapa "..mapId)
                player:SendBroadcastMessage("|cFFFF0000=== "..mapName.." ===|r")
                for _, team in pairs(teams) do
                    local memberNames = {}
                    for _, member in ipairs(team.members) do
                        table.insert(memberNames, member:GetName())
                    end
                    player:SendBroadcastMessage("|cFF00CCFF"..team.teamName..":|r "..table.concat(memberNames, ", "))
                end
            end
        end
        player:GossipComplete()
        
    elseif intid == 2 then -- Espectar arena aleatoria
        if activeSpectators[player:GetGUIDLow()] then
            player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.AlreadySpectating)
            player:GossipComplete()
            return
        end
        
        local arenas = GetActiveArenas()
        if next(arenas) == nil then
            player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.NoArena)
            player:GossipComplete()
            return
        end
        
        -- Seleccionar un equipo aleatorio
        local randomMap = nil
        local randomTeam = nil
        
        for mapId, teams in pairs(arenas) do
            for teamId, team in pairs(teams) do
                if #team.members > 0 then
                    if not randomTeam or math.random(1, 2) == 1 then
                        randomMap = mapId
                        randomTeam = team
                    end
                end
            end
        end
        
        if randomTeam and #randomTeam.members > 0 then
            local randomMember = randomTeam.members[math.random(1, #randomTeam.members)]
            TeleportToSpectate(player, randomMember)
        else
            player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.NoArena)
        end
        
        player:GossipComplete()
        
    elseif intid == 3 then -- Dejar de espectar
        RemoveSpectatorMode(player)
        player:GossipComplete()
        
    elseif intid == 4 then -- Información
        player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.SpectatingInfo)
        player:GossipComplete()
    else
        player:SendBroadcastMessage(ARENA_SPECTATOR_NPC.Messages.InvalidOption)
        player:GossipComplete()
    end
end

-- Registrar eventos
RegisterCreatureGossipEvent(ARENA_SPECTATOR_NPC.NPCEntry, 1, OnGossipHello)
RegisterCreatureGossipEvent(ARENA_SPECTATOR_NPC.NPCEntry, 2, OnGossipSelect)

-- Mensaje de carga
print("[Arena Spectator] NPC "..ARENA_SPECTATOR_NPC.NPCEntry.." cargado correctamente.")