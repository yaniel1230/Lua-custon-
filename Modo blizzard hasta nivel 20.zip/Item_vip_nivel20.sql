-- Añadir el objeto Moneda VIP (ID: 99999, ajusta si lo necesitas)
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `name`, `displayid`, `Quality`, `BuyPrice`, `SellPrice`, `InventoryType`, `Flags`, `bonding`, `description`)
VALUES 
(99999, 15, 0, 'Moneda VIP', 46779, 3, 100000, 0, 0, 1, 1, 'Permite superar el nivel 20. Dura 30 días.');