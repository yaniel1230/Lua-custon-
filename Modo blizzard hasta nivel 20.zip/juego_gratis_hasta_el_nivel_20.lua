-- =============================================
-- SISTEMA FREE-TO-PLAY ESTILO BLIZZARD
-- Versión mejorada con mensajes oficiales y mecánicas precisas
-- =============================================

local MAX_FREE_LEVEL = 20
local VIP_TOKEN_ITEM = 99999  -- ID del objeto "Suscripción VIP"
local VIP_DURATION_SECONDS = 30 * 24 * 60 * 60  -- 30 días en segundos

-- Mensajes estilo Blizzard
local SYSTEM_MESSAGES = {
    LEVEL_CAP_REACHED = "|cFFFF0000Has alcanzado el nivel máximo para jugadores Free-to-Play (20).|r\n|cFF00FF00Para continuar, necesitas adquirir una Suscripción VIP.|r",
    VIP_REQUIRED = "|cFFFF0000Requieres suscripción VIP para ganar experiencia pasando el nivel 20.|r",
    VIP_EXPIRED = "|cFFFF0000Tu suscripción VIP ha expirado.|r\n|cFF00FF00Visita un vendedor VIP para renovarla.|r",
    VIP_ACTIVE = "|cFF00FF00¡Tu suscripción VIP está activa! Puedes alcanzar el nivel máximo.|r"
}

-- =============================================
-- 1. BLOQUEO DE EXPERIENCIA (Estilo WoW)
-- =============================================
local function OnGiveXP(event, player, amount, victim)
    if player:GetLevel() >= MAX_FREE_LEVEL then
        if not player:HasItem(VIP_TOKEN_ITEM) then
            -- Mostrar mensaje de advertencia (solo una vez cada 5 minutos)
            if not player:GetData("LastXPMessage") or os.time() - player:GetData("LastXPMessage") > 300 then
                player:SendAreaTriggerMessage(SYSTEM_MESSAGES.VIP_REQUIRED)
                player:SetData("LastXPMessage", os.time())
            end
            return 0
        else
            -- Verificar si la suscripción está activa
            local item = player:GetItemByEntry(VIP_TOKEN_ITEM)
            if os.time() - item:GetCreateTime() >= VIP_DURATION_SECONDS then
                player:RemoveItem(VIP_TOKEN_ITEM, 1)
                player:SendAreaTriggerMessage(SYSTEM_MESSAGES.VIP_EXPIRED)
                return 0
            end
        end
    end
    return amount
end

-- =============================================
-- 2. NOTIFICACIONES AL LOGEAR (Estilo Battle.net)
-- =============================================
local function OnLogin(event, player)
    -- Mensaje al alcanzar nivel 20
    if player:GetLevel() >= MAX_FREE_LEVEL and not player:HasItem(VIP_TOKEN_ITEM) then
        player:SendBroadcastMessage(SYSTEM_MESSAGES.LEVEL_CAP_REACHED)
    end
    
    -- Notificar estado de suscripción
    if player:HasItem(VIP_TOKEN_ITEM) then
        local item = player:GetItemByEntry(VIP_TOKEN_ITEM)
        local remaining_time = VIP_DURATION_SECONDS - (os.time() - item:GetCreateTime())
        
        if remaining_time > 0 then
            local days_left = math.floor(remaining_time / (24 * 60 * 60))
            player:SendBroadcastMessage(string.format("|cFF00FF00Suscripción VIP activa - %d días restantes.|r", days_left))
        else
            player:RemoveItem(VIP_TOKEN_ITEM, 1)
            player:SendBroadcastMessage(SYSTEM_MESSAGES.VIP_EXPIRED)
        end
    end
    
    -- Chequeo diario de suscripción
    player:RegisterEvent(function()
        if player:HasItem(VIP_TOKEN_ITEM) then
            local item = player:GetItemByEntry(VIP_TOKEN_ITEM)
            if os.time() - item:GetCreateTime() >= VIP_DURATION_SECONDS then
                player:RemoveItem(VIP_TOKEN_ITEM, 1)
                player:SendBroadcastMessage(SYSTEM_MESSAGES.VIP_EXPIRED)
            end
        end
    end, 86400000, 0)  -- Chequeo cada 24 horas
end

-- =============================================
-- 3. RESTRICCIONES ADICIONALES (Estilo WoW)
-- =============================================
local function OnLevelUp(event, player, newLevel)
    if newLevel == MAX_FREE_LEVEL + 1 and not player:HasItem(VIP_TOKEN_ITEM) then
        -- Revertir el nivel si llegaron a 21 sin suscripción (protección anti-exploits)
        player:SetLevel(MAX_FREE_LEVEL)
        player:SendBroadcastMessage(SYSTEM_MESSAGES.VIP_REQUIRED)
    end
end

-- =============================================
-- REGISTRO DE EVENTOS
-- =============================================
RegisterPlayerEvent(12, OnGiveXP)   -- EVENT_ON_GIVE_XP
RegisterPlayerEvent(3, OnLogin)     -- EVENT_ON_LOGIN
RegisterPlayerEvent(13, OnLevelUp)  -- EVENT_ON_LEVEL_CHANGE

-- =============================================
-- COMANDO DE PRUEBA PARA JUGADORES (OPCIONAL)
-- =============================================
RegisterPlayerCommand("vipstatus", function(player)
    if player:HasItem(VIP_TOKEN_ITEM) then
        local item = player:GetItemByEntry(VIP_TOKEN_ITEM)
        local remaining = VIP_DURATION_SECONDS - (os.time() - item:GetCreateTime())
        local days = math.floor(remaining / (24 * 60 * 60))
        player:SendBroadcastMessage(string.format("|cFF00FF00Estado VIP: Activo (%d días restantes)|r", days))
    else
        player:SendBroadcastMessage("|cFFFF0000Estado VIP: Inactivo|r")
    end
end, 0)