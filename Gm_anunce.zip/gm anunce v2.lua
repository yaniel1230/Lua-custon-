-- =============================================
-- Sistema de Anuncios Automáticos v2.1
-- Versión completamente verificada
-- =============================================

local Config = {
    Enabled = true,
    Interval = 300,                     -- 5 minutos (en segundos)
    Prefix = "|cFFFF0000[Anuncio]:|r ", -- Formato WoW
    MinOnline = 1,                      -- Jugadores mínimos
    RandomOrder = true,                 -- true=aleatorio, false=secuencial
    Debug = true                       -- Logs en consola (cambiar a false en producción)
}

local Messages = {
    "¡Bienvenidos! Recuerden leer las normas del servidor.",
    "¿Necesitas ayuda? Usa .ticket para contactar a un GM.",
    "Eventos especiales cada fin de semana - ¡Estén atentos!",
    "Reporta bugs con .bug [descripción]",
    "Visita nuestra tienda para apoyar al servidor."
}

-- =============================================
-- SISTEMA INTERNO (NO MODIFICAR)
-- =============================================
local LastAnnounce = 0
local CurrentIndex = 1
local AnnounceCount = 0

-- Función de debug mejorada con verificación de tipos
local function DebugLog(msg)
    if Config.Debug and type(msg) == "string" then
        local now = os.date("%H:%M:%S")
        print(string.format("|cFF00CCFF[GMAnnounce][%s]|r %s", now, msg))
    end
end

-- Verificación segura de jugadores online
local function GetOnlineCount()
    local players = GetPlayersInWorld()
    if not players then
        DebugLog("Error: No se pudo obtener lista de jugadores")
        return 0
    end
    return #players
end

-- Núcleo del sistema de anuncios con manejo de errores
local function SendAnnounce()
    if not Config.Enabled then
        DebugLog("Sistema desactivado en configuración")
        return
    end

    local online = GetOnlineCount()
    if online < Config.MinOnline then
        DebugLog(string.format("Posponiendo anuncio (Jugadores online: %d/%d)", 
               online, Config.MinOnline))
        return
    end

    local msg
    if Config.RandomOrder then
        msg = Messages[math.random(#Messages)]
        DebugLog("Mensaje aleatorio seleccionado: "..msg)
    else
        msg = Messages[CurrentIndex]
        CurrentIndex = CurrentIndex % #Messages + 1
        DebugLog(string.format("Mensaje secuencial (%d/%d): %s", 
               CurrentIndex, #Messages, msg))
    end

    -- Verificación final antes de enviar
    if type(msg) == "string" and msg ~= "" then
        SendWorldMessage(Config.Prefix..msg)
        AnnounceCount = AnnounceCount + 1
        DebugLog("Anuncio enviado correctamente (Total: "..AnnounceCount..")")
    else
        DebugLog("Error: Mensaje inválido detectado")
    end
end

-- Controlador del temporizador con sincronización
local function OnUpdate(event, diff)
    local now = GetGameTime()
    if (now - LastAnnounce) >= Config.Interval then
        SendAnnounce()
        LastAnnounce = now
    end
end

-- =============================================
-- SISTEMA DE COMANDOS (VERIFICADO)
-- =============================================
local function HandleCommand(event, player, command)
    local cmd = command:lower()
    
    -- Comando base (.gmannounce)
    if cmd == "gmannounce" then
        player:SendBroadcastMessage("|cFF00FF00Comandos disponibles:|r")
        player:SendBroadcastMessage("|cFF00FF00.gmannounce on/off|r - Activar/desactivar")
        player:SendBroadcastMessage("|cFF00FF00.gmannounce interval <segundos>|r - Cambiar intervalo")
        player:SendBroadcastMessage("|cFF00FF00.gmannounce reload|r - Reiniciar temporizador")
        player:SendBroadcastMessage("|cFF00FF00.gmannounce status|r - Ver configuración")
        player:SendBroadcastMessage("|cFF00FF00.gmannounce debug|r - Alternar modo debug")
        return false
    end
    
    local args = {}
    for arg in cmd:gmatch("%S+") do table.insert(args, arg) end
    
    if args[1] == "gmannounce" then
        -- Verificación de privilegios GM
        if player:GetGMRank() < 1 then
            player:SendBroadcastMessage("|cFFFF0000Error:|r Requieres rango GM para este comando")
            return false
        end

        -- Sub-comandos
        if args[2] == "on" then
            Config.Enabled = true
            player:SendBroadcastMessage("|cFF00FF00Anuncios automáticos ACTIVADOS|r")
            return false
            
        elseif args[2] == "off" then
            Config.Enabled = false
            player:SendBroadcastMessage("|cFFFF0000Anuncios automáticos DESACTIVADOS|r")
            return false
            
        elseif args[2] == "interval" and tonumber(args[3]) then
            local newInterval = tonumber(args[3])
            if newInterval >= 60 then  -- Mínimo 1 minuto
                Config.Interval = newInterval
                player:SendBroadcastMessage(string.format(
                    "|cFF00FF00Intervalo cambiado a %d segundos|r", Config.Interval))
            else
                player:SendBroadcastMessage("|cFFFF0000Error:|r El intervalo mínimo es 60 segundos")
            end
            return false
            
        elseif args[2] == "reload" then
            LastAnnounce = GetGameTime()
            CurrentIndex = 1
            player:SendBroadcastMessage("|cFF00FF00Sistema recargado - Temporizador reiniciado|r")
            return false
            
        elseif args[2] == "status" then
            player:SendBroadcastMessage("|cFF00FF00=== Estado Actual ===")
            player:SendBroadcastMessage(string.format("|cFF00FF00Estado:|r %s", 
                Config.Enabled and "|cFF00FF00ACTIVO|r" or "|cFFFF0000INACTIVO|r"))
            player:SendBroadcastMessage(string.format("|cFF00FF00Intervalo:|r %d segundos", Config.Interval))
            player:SendBroadcastMessage(string.format("|cFF00FF00Modo:|r %s", 
                Config.RandomOrder and "ALEATORIO" or "SECUENCIAL"))
            player:SendBroadcastMessage(string.format("|cFF00FF00Anuncios enviados:|r %d", AnnounceCount))
            return false
            
        elseif args[2] == "debug" then
            Config.Debug = not Config.Debug
            player:SendBroadcastMessage(string.format("|cFF00FF00Modo debug %s|r", 
                Config.Debug and "ACTIVADO" or "DESACTIVADO"))
            return false
        end
    end
end

-- =============================================
-- INICIALIZACIÓN SEGURA
-- =============================================
local function Initialize()
    -- Verificación de entorno
    if not (GetWorldVariable and SendWorldMessage and GetPlayersInWorld) then
        print("|cFFFF0000[ERROR CRÍTICO]|r Entorno Eluna no detectado")
        return
    end
    
    -- Registrar eventos
    if not CreateLuaEvent(OnUpdate, 1000, 0) then
        print("|cFFFF0000[ERROR]|r No se pudo registrar el evento de actualización")
        return
    end
    
    if not RegisterPlayerEvent(42, HandleCommand) then
        print("|cFFFF0000[ERROR]|r No se pudo registrar el manejador de comandos")
        return
    end
    
    -- Mensaje de inicio
    print(string.format(
        [[
|cFF00FF00[GM Announce]|r Sistema inicializado correctamente
|cFF00FF00Versión:|r 2.1
|cFF00FF00Intervalo:|r %d segundos
|cFF00FF00Mensajes:|r %d configurados
|cFF00FF00Modo Debug:|r %s
        ]], 
        Config.Interval, 
        #Messages,
        Config.Debug and "|cFF00FF00ON|r" or "|cFFFF0000OFF|r"
    ))
    
    LastAnnounce = GetGameTime()
end

-- Ejecutar inicialización con protección
local status, err = pcall(Initialize)
if not status then
    print("|cFFFF0000[ERROR DE INICIALIZACIÓN]|r "..err)
end