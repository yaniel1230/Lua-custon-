-- =============================================
-- Sistema de Anuncios Automáticos (100% Lua)
-- Versión verificada para AzerothCore + Eluna
-- =============================================

local Config = {
    Enabled = true,                     -- true/false
    Interval = 300,                     -- segundos (5 mins)
    Prefix = "|cFFFF0000[Anuncio]:|r ", -- formato WoW
    MinOnline = 1,                      -- jugadores mínimos
    RandomOrder = true,                 -- true = aleatorio, false = secuencial
    Debug = false                       -- mostrar logs en consola
}

local Messages = {
    "¡Bienvenidos al servidor! Recuerden leer las normas en nuestro foro.",
    "¿Necesitas ayuda? Escribe .ticket para contactar a un GM.",
    "Eventos especiales cada fin de semana. ¡Consulta el calendario!",
    "¿Encontraste un error? Repórtalo con .bug [descripción]",
    "¡Visita nuestra tienda de donaciones para apoyar al servidor!",
    "El comercio justo es importante. Evita scams y reporta a los estafadores."
}

-- =============================================
-- NO EDITAR A PARTIR DE AQUÍ (Sistema interno)
-- =============================================
local LastAnnounce = 0
local CurrentIndex = 1

-- Función para debug seguro
local function DebugLog(msg)
    if Config.Debug then
        print("[GMAnnounce] "..msg)
    end
end

-- Verificación de jugadores online
local function CheckPlayersOnline()
    local players = GetPlayersInWorld()
    if not players then
        DebugLog("Error: No se pudo obtener lista de jugadores")
        return 0
    end
    return #players
end

-- Núcleo del sistema de anuncios
local function SendAnnounce()
    if not Config.Enabled then return end
    
    local onlinePlayers = CheckPlayersOnline()
    if onlinePlayers < Config.MinOnline then
        DebugLog(string.format("Posponiendo anuncio (Jugadores: %d/%d)", 
                onlinePlayers, Config.MinOnline))
        return
    end

    local msg
    if Config.RandomOrder then
        msg = Messages[math.random(#Messages)]
        DebugLog("Selección aleatoria: "..msg)
    else
        msg = Messages[CurrentIndex]
        CurrentIndex = (CurrentIndex % #Messages) + 1
        DebugLog(string.format("Selección secuencial (%d/%d): %s", 
                CurrentIndex, #Messages, msg))
    end

    SendWorldMessage(Config.Prefix..msg)
    DebugLog("Anuncio enviado correctamente")
end

-- Controlador del temporizador
local function OnUpdate(event, diff)
    local now = GetGameTime()
    if (now - LastAnnounce) >= Config.Interval then
        SendAnnounce()
        LastAnnounce = now
    end
end

-- Inicialización segura
local function Initialize()
    if not GetWorldVariable then
        print("|cFFFF0000[ERROR]|r Este script requiere AzerothCore con Eluna")
        return
    end

    LastAnnounce = GetGameTime()
    CreateLuaEvent(OnUpdate, 1000, 0)  -- 1 segundo = 1000ms
    
    print(string.format(
        "|cFF00FF00[GM Announce]|r Sistema cargado: |cFF00FFFF%d|r mensajes, intervalo |cFF00FFFF%d|r segundos",
        #Messages, Config.Interval
    ))
end

Initialize()