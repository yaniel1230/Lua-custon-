-- =============================================
-- SISTEMA DE ANUNCIOS PROFESIONAL v3.0
-- Características avanzadas para servidores WoW
-- =============================================

local Config = {
    Enabled = true,
    BaseInterval = 300,                  -- Intervalo base en segundos
    MinOnline = 5,                       -- Mínimo jugadores conectados
    AnnounceChance = 100,                -- % probabilidad de anuncio
    DynamicInterval = true,              -- Ajustar intervalo según población
    MultiChannel = true,                 -- Anunciar en múltiples canales
    DebugMode = false                    -- Mostrar logs de sistema
}

-- Sistema de mensajes multicapa
local Messages = {
    NORMAL = {
        "¡Recuerda visitar nuestra web para las últimas noticias!",
        "¿Necesitas ayuda? Escribe .ticket",
        "Eventos programados cada viernes a las 20:00"
    },
    IMPORTANT = {
        "|cFFFF0000¡NUEVO EVENTO!|r Batalla épica este sábado. Prepárate!",
        "|cFF00FF00¡ACTUALIZACIÓN!|r Nuevas misiones disponibles en Rasganorte"
    },
    WELCOME = {
        "¡Bienvenido %s al servidor! Escribe .help si necesitas ayuda.",
        "¡%s se ha unido a la aventura! Disfruta tu estancia."
    }
}

-- Variables del sistema
local LastAnnounce = {
    NORMAL = 0,
    IMPORTANT = 0,
    WELCOME = {}
}
local PlayerJoinTimes = {}

-- =============================================
-- FUNCIONES DEL SISTEMA (No tocar)
-- =============================================

-- Sistema de logging profesional
local function Log(eventType, message)
    if Config.DebugMode then
        local timestamp = os.date("[%Y-%m-%d %H:%M:%S]")
        local logMsg = string.format("%s [%s] %s", timestamp, eventType, message)
        print("|cFF00CCFF[AnnounceSys]|r "..logMsg)
        
        -- Guardar en DB (opcional)
        WorldDBExecute(string.format(
            "INSERT INTO announcements_log (type, message, timestamp) VALUES ('%s', '%s', NOW())",
            eventType:sub(1, 20),
            message:gsub("'", "''"):sub(1, 255)
        ))
    end
end

-- Calculador inteligente de intervalos
local function CalculateInterval()
    local base = Config.BaseInterval
    if not Config.DynamicInterval then return base end
    
    local online = #GetPlayersInWorld() or 1
    if online < 10 then return base * 1.5 end
    if online > 50 then return math.max(120, base * 0.6) end
    return base
end

-- Sistema de anuncios multicanal
local function SendMultiAnnounce(msg, msgType)
    -- Canal global principal
    SendWorldMessage("|TInterface\\Icons\\inv_misc_note_01:15|t "..msg)
    
    -- Canales adicionales
    if Config.MultiChannel then
        if msgType == "IMPORTANT" then
            SendWorldMessage("|cFFFFA500[GLOBAL]|r "..msg)
        end
        
        -- Enviar a canal de moderadores (si existe)
        local modMsg = string.format("|cFF00FF00[STAFF]|r Anuncio enviado: %s", msg)
        SendGMMessage(modMsg)
    end
end

-- Procesador de mensajes dinámicos
local function FormatMessage(msg, player)
    if not player then return msg end
    return msg:gsub("%%s", player:GetName())
end

-- =============================================
-- NÚCLEO DE ANUNCIOS
-- =============================================

local function SendScheduledAnnounce()
    if not Config.Enabled or math.random(100) > Config.AnnounceChance then return end
    
    local now = GetGameTime()
    local interval = CalculateInterval()
    
    -- Anuncio normal
    if (now - LastAnnounce.NORMAL) >= interval then
        local msg = Messages.NORMAL[math.random(#Messages.NORMAL)]
        SendMultiAnnounce(msg, "NORMAL")
        LastAnnounce.NORMAL = now
        Log("NORMAL", "Anuncio enviado: "..msg)
    end
    
    -- Anuncio importante (intervalo más largo)
    if (now - LastAnnounce.IMPORTANT) >= (interval * 3) then
        if math.random(100) < 30 then  -- 30% de chance
            local msg = Messages.IMPORTANT[math.random(#Messages.IMPORTANT)]
            SendMultiAnnounce(msg, "IMPORTANT")
            LastAnnounce.IMPORTANT = now
            Log("IMPORTANT", "Anuncio importante: "..msg)
        end
    end
end

-- =============================================
-- SISTEMA DE BIENVENIDA
-- =============================================

local function OnPlayerLogin(event, player)
    local guid = player:GetGUIDLow()
    local now = GetGameTime()
    
    -- Solo mensaje si pasaron +5 mins desde último login
    if not PlayerJoinTimes[guid] or (now - PlayerJoinTimes[guid]) > 300 then
        if math.random(100) < 80 then  -- 80% de probabilidad
            local msg = Messages.WELCOME[math.random(#Messages.WELCOME)]
            SendWorldMessage(FormatMessage(msg, player))
            Log("WELCOME", string.format("Mensaje para %s", player:GetName()))
        end
    end
    
    PlayerJoinTimes[guid] = now
end

-- =============================================
-- COMANDOS AVANZADOS
-- =============================================

local function HandleAnnounceCommand(event, player, command)
    local cmd = command:lower()
    
    -- Comando base (.announce)
    if cmd == "announce" then
        player:SendBroadcastMessage("|cFF00FF00Sistema de Anuncios v3.0|r")
        player:SendBroadcastMessage("|cFF00FF00.announce send <mensaje>|r - Enviar anuncio global")
        player:SendBroadcastMessage("|cFF00FF00.announce toggle|r - Activar/desactivar sistema")
        player:SendBroadcastMessage("|cFF00FF00.announce stats|r - Ver estadísticas")
        return false
    end
    
    local args = {}
    for arg in cmd:gmatch("%S+") do table.insert(args, arg) end
    
    if args[1] == "announce" and player:GetGMRank() > 0 then
        if args[2] == "send" then
            local msg = table.concat(args, " ", 3)
            if msg and msg ~= "" then
                SendMultiAnnounce(msg, "MANUAL")
                player:SendBroadcastMessage("|cFF00FF00Anuncio enviado correctamente|r")
                Log("MANUAL", string.format("Anuncio manual de %s: %s", player:GetName(), msg))
            end
            return false
            
        elseif args[2] == "toggle" then
            Config.Enabled = not Config.Enabled
            player:SendBroadcastMessage(string.format("|cFF00FF00Sistema %s|r", 
                Config.Enabled and "activado" or "desactivado"))
            return false
            
        elseif args[2] == "stats" then
            local online = #GetPlayersInWorld() or 0
            player:SendBroadcastMessage("|cFF00FF00=== Estadísticas ===")
            player:SendBroadcastMessage(string.format("|cFF00FF00Jugadores online:|r %d", online))
            player:SendBroadcastMessage(string.format("|cFF00FF00Intervalo actual:|r %d segundos", CalculateInterval()))
            return false
        end
    end
end

-- =============================================
-- INICIALIZACIÓN DEL SISTEMA
-- =============================================

local function Initialize()
    -- Crear tabla de logs si no existe
    WorldDBExecute([[
        CREATE TABLE IF NOT EXISTS announcements_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            type VARCHAR(20),
            message VARCHAR(255),
            timestamp DATETIME
        )
    ]])
    
    -- Registrar eventos
    RegisterPlayerEvent(3, OnPlayerLogin)   -- EVENT_PLAYER_LOGIN
    RegisterPlayerEvent(42, HandleAnnounceCommand) -- EVENT_PLAYER_COMMAND
    CreateLuaEvent(function() SendScheduledAnnounce() end, 1000, 0) -- Check cada 1 segundo
    
    Log("SYSTEM", string.format(
        "Sistema inicializado. Intervalo base: %d segundos", Config.BaseInterval))
end

Initialize()