-- Crear template del NPC
INSERT INTO `creature_template` (`entry`, `name`, `subname`, `minlevel`, `maxlevel`, `faction`, `npcflag`, `scale`, `unit_class`, `type`, `ScriptName`) 
VALUES 
(445050, 'Informador del Servidor', 'Estadísticas en línea', 80, 80, 35, 1, 1, 1, 7, '');

-- Asignar modelo visual
INSERT INTO `creature_template_model` (`CreatureID`, `Idx`, `CreatureDisplayID`, `DisplayScale`, `Probability`) 
VALUES 
(445050, 0, 19646, 1, 1);