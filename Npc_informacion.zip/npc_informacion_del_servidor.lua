local NPC_ID = 445050 -- ID único para el NPC (nuevo ID solicitado)
local CONFIG = {
    DISPLAY_ID = 19646, -- Modelo visual (humano con túnica)
    SCALE = 1.0,
    
    -- Ubicaciones en todas las zonas iniciales
    SPAWNS = {
        -- Alianza
        {map = 0, x = -8943.53, y = -132.933, z = 83.5312, o = 0.829156}, -- Ventormenta
        {map = 0, x = -5603.76, y = -479.441, z = 396.981, o = 0.675728}, -- Kharanos
        {map = 1, x = 9945.13, y = 2282.55, z = 1341.4, o = 1.59531}, -- Darnassus
        {map = 530, x = -3965.7, y = -11653.6, z = -138.844, o = 1.39626}, -- El Exodar
        
        -- Horda
        {map = 1, x = 1601.08, y = -4378.69, z = 9.9846, o = 2.14362}, -- Orgrimmar
        {map = 0, x = 1637.21, y = 240.132, z = -43.1034, o = 3.13147}, -- Entrañas
        {map = 1, x = -1277.37, y = 124.804, z = 131.287, o = 5.22274}, -- Cima del Trueno
        {map = 530, x = 9400.81, y = -7278.57, z = 14.2277, o = 5.74213}, -- Lunargenta
        
        -- Zonas neutrales
        {map = 530, x = -1824.32, y = 5417.23, z = -12.4274, o = 2.44346}, -- Shattrath
        {map = 571, x = 5804.15, y = 624.771, z = 647.767, o = 1.64}, -- Dalaran
        {map = 1, x = 16222.1, y = 16252.1, z = 12.5872, o = 3.51188}, -- Isla GM
    },
    
    -- Configuración visual
    SHOW_CLASS_COLORS = true,
    SHOW_RACE_ICONS = true,
    SHOW_ZONE_INFO = true,
    SHOW_LEVEL_COLORS = true,
    SHOW_FACTION_HEADERS = true
}

-- Iconos y colores
local RACE_ICONS = {
    [1] = 1, [2] = 3, [3] = 4, [4] = 2, [5] = 5, [6] = 6, [7] = 7, [8] = 8, [10] = 9, [11] = 10
}

local CLASS_COLORS = {
    [1] = "C79C6E", [2] = "F58CBA", [3] = "ABD473", [4] = "FFF569",
    [5] = "FFFFFF", [6] = "C41F3B", [7] = "0070DE", [8] = "69CCF0",
    [9] = "9482C9", [11] = "FF7D0A"
}

-- Función para formatear el tiempo online
local function GetOnlineTimeString(seconds)
    local days = math.floor(seconds / 86400)
    local hours = math.floor((seconds % 86400) / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    
    local str = ""
    if days > 0 then str = str..days.."d " end
    if hours > 0 then str = str..hours.."h " end
    str = str..minutes.."m"
    return str
end

-- Menú principal
local function OnGossipHello(event, player, object)
    player:GossipClearMenu()
    
    -- Cabecera
    player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\ICONS\\Achievement_Character_Human_Male:30:30:-15:0|tInformación del Servidor", 0, 0)
    player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "-------------------------", 0, 0)
    
    -- Jugadores conectados
    local onlineCount = #GetPlayersInWorld()
    player:GossipMenuAddItem(GOSSIP_ICON_CHAT, 
        "|TInterface\\ICONS\\Achievement_Character_Human_Female:25:25:-15:0|tJugadores: |cFF00FF00"..onlineCount.."|r", 
        0, 1, false, "Ver lista completa de jugadores")
    
    -- Tiempo online
    player:GossipMenuAddItem(GOSSIP_ICON_CHAT, 
        "|TInterface\\ICONS\\Achievement_BG_winAB_underXminutes:25:25:-15:0|tOnline: |cFF00FF00"..GetOnlineTimeString(GetUptime()).."|r", 
        0, 2)
    
    player:GossipSendMenu(1, object)
end

-- Menú de selección
local function OnGossipSelect(event, player, object, sender, intid, code)
    if intid == 1 then -- Lista de jugadores
        player:GossipClearMenu()
        local onlinePlayers = GetPlayersInWorld()
        
        -- Título
        player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\ICONS\\Achievement_GuildPerk_EverybodysFriend:25:25:-15:0|tJugadores ("..#onlinePlayers..")", 0, 0)
        player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "-------------------------", 0, 0)
        
        if #onlinePlayers > 0 then
            -- Separar por facción
            local alliance, horde = {}, {}
            for _, guid in ipairs(onlinePlayers) do
                local p = GetPlayerByGUID(guid)
                if p then
                    if p:GetTeam() == 0 then table.insert(alliance, p)
                    else table.insert(horde, p) end
                end
            end
            
            -- Mostrar Alianza
            if #alliance > 0 and CONFIG.SHOW_FACTION_HEADERS then
                player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\PVPFrame\\Pvp-Currency-Alliance:25:25:-15:0|t |cFF2459FFAlianza|r", 0, 0)
                player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "-------------------------", 0, 0)
            end
            
            for _, p in ipairs(alliance) do
                AddPlayerToGossip(player, p)
            end
            
            -- Mostrar Horda
            if #horde > 0 and CONFIG.SHOW_FACTION_HEADERS then
                if #alliance > 0 then
                    player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "-------------------------", 0, 0)
                end
                player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\PVPFrame\\Pvp-Currency-Horde:25:25:-15:0|t |cFFFF0000Horda|r", 0, 0)
                player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "-------------------------", 0, 0)
            end
            
            for _, p in ipairs(horde) do
                AddPlayerToGossip(player, p)
            end
        else
            player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "No hay jugadores conectados", 0, 0)
        end
        
        -- Pie de menú
        player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "-------------------------", 0, 0)
        player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\ICONS\\Ability_Spy:25:25:-15:0|tVolver", 0, 3)
        player:GossipSendMenu(1, object)
        
    elseif intid == 2 then -- Actualizar tiempo
        player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\ICONS\\Achievement_BG_winAB_underXminutes:25:25:-15:0|tOnline: |cFF00FF00"..GetOnlineTimeString(GetUptime()).."|r", 0, 2)
        player:GossipMenuAddItem(GOSSIP_ICON_CHAT, "|TInterface\\ICONS\\Ability_Spy:25:25:-15:0|tVolver", 0, 3)
        player:GossipSendMenu(1, object)
        
    elseif intid == 3 then -- Volver
        OnGossipHello(event, player, object)
    end
end

-- Añadir jugador al menú
local function AddPlayerToGossip(player, target)
    local name = target:GetName()
    local race = target:GetRace()
    local class = target:GetClass()
    local level = target:GetLevel()
    local zone = target:GetZoneName()
    
    local line = CONFIG.SHOW_RACE_ICONS and RACE_ICONS[race] and 
        ("|TInterface\\Glues\\CharacterCreate\\UI-CharacterCreate-Races:20:20:0:0:256:256:"..((race-1)*64)..":"..(race*64)..":0:0|t ") or ""
    
    line = line..(CONFIG.SHOW_CLASS_COLORS and CLASS_COLORS[class] and 
        ("|cFF"..CLASS_COLORS[class]..name.."|r") or name)
    
    line = line..(CONFIG.SHOW_LEVEL_COLORS and 
        (" |cFF"..((level == 80) and "FF0000" or "00FF00").."["..level.."]|r") or (" ["..level.."]"))
    
    line = line..(CONFIG.SHOW_ZONE_INFO and (" |cFFa335ee("..zone..")|r") or "")
    
    player:GossipMenuAddItem(GOSSIP_ICON_CHAT, line, 0, 0)
end

-- Crear spawns automáticamente
local function CreateSpawns()
    for i, spawn in ipairs(CONFIG.SPAWNS) do
        local guid = NPC_ID * 100 + i
        if not WorldDBQuery("SELECT guid FROM creature WHERE guid = "..guid) then
            WorldDBExecute(string.format(
                "INSERT INTO creature (guid, id, map, position_x, position_y, position_z, orientation, spawntimesecs) "..
                "VALUES (%d, %d, %d, %f, %f, %f, %f, 300)",
                guid, NPC_ID, spawn.map, spawn.x, spawn.y, spawn.z, spawn.o
            ))
            print("[NPC ServerInfo] Spawn creado en mapa "..spawn.map.." ("..spawn.x..", "..spawn.y..")")
        end
    end
end

-- Registrar eventos
RegisterCreatureGossipEvent(NPC_ID, 1, OnGossipHello)
RegisterCreatureGossipEvent(NPC_ID, 2, OnGossipSelect)
RegisterServerEvent(33, CreateSpawns) -- Ejecutar al iniciar el servidor

print("[NPC ServerInfo] Script cargado. NPC ID: "..NPC_ID)